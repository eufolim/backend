package com.estudantes_web.estudantes_web;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EstudantesWebApplication {

	public static void main(String[] args) {
		SpringApplication.run(EstudantesWebApplication.class, args);
	}

}
