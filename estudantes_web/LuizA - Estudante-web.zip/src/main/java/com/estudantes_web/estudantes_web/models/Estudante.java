package com.estudantes_web.estudantes_web.models;

public class Estudante {
    String nome;
    Integer codigo;
    String curso;
    String email;
    String telefone;
    
    public Estudante(String nome, Integer codigo, String curso, String email, String telefone) {
        this.nome = nome;
        this.codigo = codigo;
        this.curso = curso;
        this.email = email;
        this.telefone = telefone;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Integer getCodigo() {
        return codigo;
    }

    public void setCodigo(Integer codigo) {
        this.codigo = codigo;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }
}
