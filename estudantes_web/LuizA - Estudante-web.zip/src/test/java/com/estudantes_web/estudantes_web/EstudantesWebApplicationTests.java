package com.estudantes_web.estudantes_web;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EstudantesWebApplicationTests {

	@Test
	void contextLoads() {
	}

}
